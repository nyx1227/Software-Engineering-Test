f = open("yq_in.txt", "r")
fo = open("yq_out.txt", 'w')
lines = f.readlines()  # 读取所有行
province = []  # 省份列表
sole_province = []  # 去除了重复省份值的列表
city = []  # 城市列表
num = []  # 新增人数列表
total_num = []  # 统计某省新增人数
for line in lines:
    items = line.strip().split("\t")
    province.append(items[0])  # 把文件的第1列添加进省份列表
    city.append(items[1])  # 把文件的第2列添加进城市列表
    num.append(items[2])  # 把文件的第3列添加进人数列表

for x in province:
    if x not in sole_province:
        sole_province.append(x)  # 去除省份列表重复值，不重复元素添加进sole_province
for i in sole_province:
    total = 0
    for j in range(len(province)):
        if province[j] == i:
            total += int(num[j])
    total_num.append(total)

pro_num = list(zip(sole_province, total_num))
pro_num = sorted(pro_num, key=(lambda x: x[1]), reverse=True)
for i, j in pro_num:
    print(i, j, file=fo)
    pro_city = []
    city_num = []
    for k in range(len(province)):
        if province[k] == i:
            pro_city.append(city[k])
            city_num.append(num[k])

    for m in range(1, len(city_num)):
        for n in range(0, len(city_num) - m):
            if int(city_num[n]) < int(city_num[n + 1]):
                pro_city[n], pro_city[n + 1] = pro_city[n + 1], pro_city[n]
                city_num[n], city_num[n + 1] = city_num[n + 1], city_num[n]
    for x in range(len(city_num)):
        print(pro_city[x] + "\t" + city_num[x], file=fo)

    print(file=fo)

f.close()
fo.close()

